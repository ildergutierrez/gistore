// ============================================================
//  user/recuperar/recuperar.js
//  Lee el token de la URL, valida y cambia la contraseña
//  POST → ../../backend/recuperar.php
// ============================================================

// ── Token CSRF (igual que el resto del portal) ────────────
let _csrfToken = null;
async function getToken() {
  if (_csrfToken) return _csrfToken;
  try {
    const resp = await fetch('../../backend/tokens.php?accion=obtener', { credentials: 'include' });
    const data = await resp.json();
    _csrfToken = data.token || '';
  } catch { _csrfToken = ''; }
  return _csrfToken;
}

// ── Helpers DOM ───────────────────────────────────────────
function el(id) { return document.getElementById(id); }

function mostrarError(msg) {
  el('textoError').textContent = msg;
  el('msgError').classList.add('visible');
}
function ocultarError() {
  el('msgError').classList.remove('visible');
}

function btnCargando(btn, estado) {
  btn.disabled = estado;
  btn.classList.toggle('cargando', estado);
}

// ── Ver/ocultar contraseña ────────────────────────────────
[['btnVerNueva', 'fPassNueva'],
 ['btnVerConf',  'fPassConf']].forEach(([b, i]) => {
  el(b)?.addEventListener('click', () => {
    const inp = el(i);
    inp.type        = inp.type === 'password' ? 'text' : 'password';
    el(b).textContent = inp.type === 'password' ? '👁' : '🙈';
  });
});

// ── Leer token de la URL ──────────────────────────────────
const params       = new URLSearchParams(window.location.search);
const tokenRecup   = params.get('token') || '';
const subtitulo    = el('subtitulo');
const formulario   = el('formulario');

if (!tokenRecup) {
  subtitulo.textContent = 'El enlace no es válido. Solicita uno nuevo desde el login.';
  el('btnCambiar').disabled = true;
  el('fPassNueva').disabled = true;
  el('fPassConf').disabled  = true;
} else {
  subtitulo.textContent = 'Ingresa tu nueva contraseña. El enlace es válido por 1 hora.';
}

// ── Cambiar contraseña ────────────────────────────────────
el('btnCambiar')?.addEventListener('click', async () => {
  ocultarError();

  const passNueva = el('fPassNueva').value;
  const passConf  = el('fPassConf').value;

  if (!tokenRecup)              { mostrarError('Enlace inválido. Solicita uno nuevo.'); return; }
  if (passNueva.length < 6)     { mostrarError('La contraseña debe tener al menos 6 caracteres.'); return; }
  if (passNueva !== passConf)   { mostrarError('Las contraseñas no coinciden.'); return; }

  const btn = el('btnCambiar');
  btnCargando(btn, true);

  try {
    const csrfToken = await getToken();

    const body = new URLSearchParams({
      accion:     'cambiar',
      token:      tokenRecup,   // token de recuperación (de la URL)
      pass_nueva: passNueva,
      pass_conf:  passConf,
    });

    const resp = await fetch('../../backend/recuperar.php', {
      method:      'POST',
      credentials: 'include',
      headers:     { 'Content-Type': 'application/x-www-form-urlencoded' },
      body:        body.toString(),
    });

    const data = await resp.json();

    if (!data.ok) {
      mostrarError(data.error || 'No se pudo cambiar la contraseña.');
      btnCargando(btn, false);
      return;
    }

    // Éxito — mostrar mensaje y redirigir
    formulario.style.display = 'none';
    el('msgOk').classList.add('visible');

    setTimeout(() => {
      window.location.href = '../index.html';
    }, 2500);

  } catch (e) {
    console.error(e);
    mostrarError('Error de conexión. Intenta de nuevo.');
    btnCargando(btn, false);
  }
});
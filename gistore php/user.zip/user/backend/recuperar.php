<?php
// ============================================================
//  user/backend/recuperar.php
//  Acciones:
//    solicitar  (POST) → genera token y envía correo con PHPMailer
//    cambiar    (POST) → valida token y actualiza contraseña
// ============================================================

if (session_status() === PHP_SESSION_NONE)
    session_start();

set_exception_handler(function ($e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
    exit;
});

header('Content-Type: application/json');

// ── PHPMailer ─────────────────────────────────────────────
// Instalar con: composer require phpmailer/phpmailer
require_once __DIR__ . '/../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// ── Conexión BD ───────────────────────────────────────────
require_once __DIR__ . '/../../backend/conexion.php';
$pdo = __Conectar();

// ── Helpers ───────────────────────────────────────────────
function ok(mixed $datos = null): never {
    echo json_encode(['ok' => true, 'datos' => $datos], JSON_UNESCAPED_UNICODE);
    exit;
}
function err(string $msg, int $code = 400): never {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── Enmascarar correo: ju***@gmail.com ────────────────────
function enmascararCorreo(string $correo): string {
    [$local, $dominio] = explode('@', $correo, 2);
    $visible = substr($local, 0, min(2, strlen($local)));
    return $visible . '***@' . $dominio;
}

// ── Envío con PHPMailer ───────────────────────────────────
function enviarCorreoRecuperacion(string $destinatario, string $enlace): void {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'mail.gistore.com.co';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'notificaciones@gistore.com.co';
        $mail->Password   = 'G15tores260*';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom('notificaciones@gistore.com.co', 'GI Store');
        $mail->addAddress($destinatario);

        $mail->isHTML(true);
        $mail->Subject = 'Recuperar contraseña — GI Store';
        $mail->Body    = "
        <div style='font-family:Inter,sans-serif;max-width:480px;margin:0 auto;padding:2rem'>
          <div style='text-align:center;margin-bottom:1.5rem'>
            <div style='display:inline-block;background:#1a6b3c;border-radius:12px;padding:.75rem 1.5rem'>
              <span style='color:#fff;font-size:1.1rem;font-weight:800'>GI Store</span>
            </div>
          </div>
          <h2 style='color:#0f172a;font-size:1.25rem;margin-bottom:.5rem'>Recupera tu contraseña</h2>
          <p style='color:#475569;font-size:.9rem;line-height:1.6;margin-bottom:1.5rem'>
            Recibimos una solicitud para restablecer la contraseña de tu cuenta en GI Store.
            Haz clic en el botón para continuar. El enlace es válido por <strong>1 hora</strong>.
          </p>
          <div style='text-align:center;margin-bottom:1.5rem'>
            <a href='{$enlace}'
               style='display:inline-block;background:#1a6b3c;color:#fff;text-decoration:none;
                      padding:.85rem 2rem;border-radius:9px;font-weight:700;font-size:.95rem'>
              🔑 Cambiar contraseña
            </a>
          </div>
          <p style='color:#94a3b8;font-size:.78rem;line-height:1.6;border-top:1px solid #e2e8f0;padding-top:1rem'>
            Si no solicitaste este cambio, ignora este correo — tu contraseña no cambiará.<br/>
            Este enlace expirará automáticamente en 1 hora.
          </p>
          <p style='color:#94a3b8;font-size:.75rem;margin-top:.5rem'>© 2026 GI Store · Aguachica, Cesar</p>
        </div>";

        $mail->AltBody = "Recupera tu contraseña en GI Store.\n\nEnlace (válido 1 hora):\n{$enlace}\n\nSi no lo solicitaste, ignora este correo.";

        $mail->send();
    } catch (Exception $e) {
        error_log('PHPMailer error: ' . $mail->ErrorInfo);
        // No detenemos el flujo — la respuesta al usuario es siempre genérica
    }
}

// ════════════════════════════════════════════════════════════
//  ACCION: solicitar
//  POST: correo
// ════════════════════════════════════════════════════════════
function accion_solicitar($pdo): void {
    $correo = trim($_POST['correo'] ?? '');
    if (!$correo || !filter_var($correo, FILTER_VALIDATE_EMAIL))
        err('Ingresa un correo válido.');

    // Buscar usuario vendedor activo
    $stmt = $pdo->prepare("
        SELECT id, correo, activo FROM usuarios
        WHERE correo = ? AND rol = 2
        LIMIT 1
    ");
    $stmt->execute([$correo]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    // Si no existe o está inactivo → respuesta genérica sin revelar
    if (!$usuario || !$usuario['activo']) {
        ok(['enviado' => true, 'correo_mask' => enmascararCorreo($correo)]);
    }

    // Generar token de recuperación
    $token     = bin2hex(random_bytes(32));
    $expira_en = date('Y-m-d H:i:s', time() + 3600);

    // Limpiar tokens anteriores
    $pdo->prepare("DELETE FROM wpis WHERE usuario_id = ?")->execute([$usuario['id']]);

    // Guardar token
    $stmt = $pdo->prepare("
        INSERT INTO wpis (id, usuario_id, ip, user_agent, token, expira_en)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        bin2hex(random_bytes(8)),
        $usuario['id'],
        $_SERVER['REMOTE_ADDR'] ?? '',
        substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
        $token,
        $expira_en,
    ]);

    // Enlace de recuperación
    $protocolo = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host      = $_SERVER['HTTP_HOST'];
    $enlace    = "{$protocolo}://{$host}/user/recuperar/index.html?token={$token}";

    // Enviar correo
    enviarCorreoRecuperacion($correo, $enlace);

    ok(['enviado' => true, 'correo_mask' => enmascararCorreo($correo)]);
}

// ════════════════════════════════════════════════════════════
//  ACCION: cambiar
//  POST: token, pass_nueva, pass_conf
// ════════════════════════════════════════════════════════════
function accion_cambiar($pdo): void {
    $token      = trim($_POST['token']      ?? '');
    $pass_nueva = trim($_POST['pass_nueva'] ?? '');
    $pass_conf  = trim($_POST['pass_conf']  ?? '');

    if (!$token)                    err('Token inválido.');
    if (strlen($pass_nueva) < 6)    err('La contraseña debe tener al menos 6 caracteres.');
    if ($pass_nueva !== $pass_conf) err('Las contraseñas no coinciden.');

    // Buscar token válido
    $stmt = $pdo->prepare("
        SELECT usuario_id FROM wpis
        WHERE token = ? AND expira_en > NOW()
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $fila = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$fila) err('El enlace ha expirado o no es válido. Solicita uno nuevo desde el login.');

    $usuario_id = (int)$fila['usuario_id'];

    // Actualizar contraseña
    $pdo->prepare("
        UPDATE usuarios SET password_hash = ?, actualizado_en = NOW()
        WHERE id = ?
    ")->execute([password_hash($pass_nueva, PASSWORD_DEFAULT), $usuario_id]);

    // Invalidar token
    $pdo->prepare("DELETE FROM wpis WHERE usuario_id = ?")->execute([$usuario_id]);

    ok(['cambiado' => true]);
}

// ── Router ────────────────────────────────────────────────
$accion = $_POST['accion'] ?? '';
$metodo = $_SERVER['REQUEST_METHOD'];

match (true) {
    $accion === 'solicitar' && $metodo === 'POST' => accion_solicitar($pdo),
    $accion === 'cambiar'   && $metodo === 'POST' => accion_cambiar($pdo),
    default => err('Acción no reconocida.', 404),
};
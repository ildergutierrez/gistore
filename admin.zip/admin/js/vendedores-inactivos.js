// ============================================================
//  vendedores-inactivos.js — Vendedores desactivados
//  Permite ver y reactivar vendedores con estado="desactivado"
// ============================================================
import { cerrarSesion, protegerPagina } from "./auth.js";
import { obtenerVendedoresDesactivados, reactivarVendedor } from "./db.js";
import { fechaHoy, btnCargando, abrirModal, cerrarModal } from "./ui.js";

protegerPagina("../index.html");

document.getElementById("fechaHoy").textContent = fechaHoy();
document.getElementById("btnSalir").addEventListener("click", async () => {
  await cerrarSesion(); window.location.href = "../index.html";
});

// ── Estado global ─────────────────────────────────────────
let desactivados = [];
let idReactivar  = "";

// ── Cargar tabla ──────────────────────────────────────────
async function cargar() {
  try {
    desactivados = await obtenerVendedoresDesactivados();
    document.getElementById("totalDesactivados").textContent =
      desactivados.length + " desactivado" + (desactivados.length !== 1 ? "s" : "");
    renderTabla();
  } catch (e) {
    console.error("Error cargando vendedores desactivados:", e);
  }
}

function renderTabla() {
  const wrap = document.getElementById("tablaWrap");

  if (!desactivados.length) {
    wrap.innerHTML = '<p class="vacio-txt">No hay vendedores desactivados. ✅</p>';
    return;
  }

  wrap.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Color</th>
          <th>Nombre</th>
          <th>Ciudad</th>
          <th>WhatsApp</th>
          <th>Correo</th>
          <th>Acceso</th>
          <th>Acción</th>
        </tr>
      </thead>
      <tbody>
        ${desactivados.map(v => `
          <tr style="opacity:.85">
            <td>
              <div style="width:22px;height:22px;border-radius:50%;
                          background:${v.color || "#94a3b8"};
                          border:2px solid #ddd;filter:grayscale(40%)"></div>
            </td>
            <td><strong>${v.nombre}</strong></td>
            <td>${v.ciudad || "—"}</td>
            <td>${v.whatsapp
              ? `<a href="https://wa.me/${v.whatsapp}" target="_blank"
                    style="color:var(--verde);text-decoration:none">📱 ${v.whatsapp}</a>`
              : "—"}</td>
            <td>${v.correo || "—"}</td>
            <td>${v.uid_auth
              ? `<span class="badge badge-activo" title="UID: ${v.uid_auth}">✓ Con acceso</span>`
              : `<span class="badge badge-inactivo">Sin acceso</span>`}</td>
            <td>
              <button class="btn-reactivar" data-id="${v.id}" data-nombre="${v.nombre}">
                ✅ Reactivar
              </button>
            </td>
          </tr>`).join("")}
      </tbody>
    </table>`;

  wrap.querySelectorAll(".btn-reactivar").forEach(btn =>
    btn.addEventListener("click", () => abrirReactivar(btn.dataset.id, btn.dataset.nombre))
  );
}

// ── Modal reactivar ───────────────────────────────────────
function abrirReactivar(id, nombre) {
  idReactivar = id;
  document.getElementById("nombreReactivar").textContent = nombre;
  abrirModal("modalReactivar");
}

document.getElementById("btnConfirmarReactivar").addEventListener("click", async () => {
  const btn = document.getElementById("btnConfirmarReactivar");
  btnCargando(btn, true);
  try {
    const { vigente } = await reactivarVendedor(idReactivar);
    cerrarModal("modalReactivar");
    await cargar();

    // Mostrar aviso según si tenía membresía o no
    if (!vigente) {
      alert(
        "El vendedor fue reactivado pero no tiene membresía vigente.\n" +
        "Sus productos permanecen ocultos hasta asignarle una membresía activa."
      );
    }
  } catch (e) {
    console.error("Error al reactivar vendedor:", e);
    alert("Hubo un problema al reactivar. Intenta de nuevo.");
  } finally {
    btnCargando(btn, false);
  }
});

// ── Cerrar modal ──────────────────────────────────────────
document.getElementById("btnCancelarReactivar").addEventListener("click",
  () => cerrarModal("modalReactivar")
);
document.getElementById("modalReactivar").addEventListener("click", e => {
  if (e.target === document.getElementById("modalReactivar")) cerrarModal("modalReactivar");
});

cargar();
// ============================================================
//  perfil.js — Editar perfil del vendedor
// ============================================================
import { cerrarSesion } from "./auth.js";
import { obtenerVendedorPorUid, actualizarVendedor,
         obtenerMembresiaVendedor, membresiaVigente } from "./db.js";
import { fechaHoy, btnCargando } from "./ui.js";
import { auth } from "./firebase.js";
import { onAuthStateChanged, updatePassword,
         reauthenticateWithCredential, EmailAuthProvider }
  from "https://www.gstatic.com/firebasejs/12.10.0/firebase-auth.js";

// Ocultar cuerpo hasta confirmar sesión
document.body.style.visibility = "hidden";

document.getElementById("fechaHoy").textContent = fechaHoy();
document.getElementById("btnSalir").addEventListener("click", async () => {
  await cerrarSesion(); window.location.href = "../index.html";
});

// Ver/ocultar contraseñas
[
  ["btnVerPassActual", "fPassActual"],
  ["btnVerPassNueva",  "fNewPass"],
  ["btnVerPassConf",   "fConfPass"],
].forEach(([btnId, inputId]) => {
  document.getElementById(btnId).addEventListener("click", () => {
    const input = document.getElementById(inputId);
    const btn   = document.getElementById(btnId);
    if (input.type === "password") { input.type = "text";     btn.textContent = "🙈"; }
    else                           { input.type = "password"; btn.textContent = "👁"; }
  });
});

let vendedor = null;

// Un solo listener que maneja auth + carga de datos
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "../index.html";
    return;
  }
  document.body.style.visibility = "visible";

  try {
    vendedor = await obtenerVendedorPorUid(user.uid);
    if (!vendedor) {
      document.getElementById("fNombre").value = "";
      document.getElementById("fNombre").placeholder = "Perfil no encontrado — contacta al admin";
      return;
    }

    document.getElementById("vendedorNombre").textContent = vendedor.nombre;
    document.getElementById("fNombre").value   = vendedor.nombre   || "";
    document.getElementById("fCiudad").value   = vendedor.ciudad   || "";
    document.getElementById("fWhatsapp").value = vendedor.whatsapp || "";
    document.getElementById("fCorreo").value   = vendedor.correo   || user.email || "";

    // Info cuenta
    document.getElementById("infoEstado").textContent = vendedor.estado === "activo" ? "Activo" : "Inactivo";
    document.getElementById("infoEstado").className   = "badge badge-" + (vendedor.estado === "activo" ? "activo" : "inactivo");
    document.getElementById("infoCreadoEn").textContent = vendedor.creado_en
      ? new Date(vendedor.creado_en).toLocaleDateString("es-CO") : "—";

    // Membresía
    const mem = await obtenerMembresiaVendedor(vendedor.id);
    const elMem = document.getElementById("infoMembresia");
    if (!mem) {
      elMem.textContent = "Sin membresía";
      elMem.style.color = "var(--error)";
    } else if (!membresiaVigente(mem)) {
      elMem.textContent = "Vencida (" + mem.fecha_fin + ")";
      elMem.style.color = "var(--error)";
    } else {
      const dias = Math.ceil((new Date(mem.fecha_fin) - new Date()) / (1000*60*60*24));
      elMem.textContent = "Activa · " + dias + " días restantes";
      elMem.style.color = "var(--verde)";
    }

  } catch (e) {
    console.error("Error cargando perfil:", e);
  }
});

// ── Guardar datos del perfil ──────────────────────────────
document.getElementById("btnGuardarPerfil").addEventListener("click", async () => {
  if (!vendedor) { mostrarError("Perfil no cargado. Recarga la página."); return; }

  const nombre   = document.getElementById("fNombre").value.trim();
  const ciudad   = document.getElementById("fCiudad").value.trim();
  const whatsapp = document.getElementById("fWhatsapp").value.trim();

  if (!nombre) { mostrarError("El nombre es obligatorio."); return; }

  const btn = document.getElementById("btnGuardarPerfil");
  btnCargando(btn, true);
  ocultarMensajes();

  try {
    await actualizarVendedor(vendedor.id, { nombre, ciudad, whatsapp });
    sessionStorage.setItem("vendedor_nombre", nombre);
    document.getElementById("vendedorNombre").textContent = nombre;
    mostrarOk("✓ Datos actualizados correctamente.");
  } catch (e) {
    mostrarError("Error al guardar. Intenta de nuevo.");
    console.error(e);
  } finally {
    btnCargando(btn, false);
  }
});

// ── Cambiar contraseña ────────────────────────────────────
document.getElementById("btnCambiarPass").addEventListener("click", async () => {
  const passActual = document.getElementById("fPassActual").value;
  const newPass    = document.getElementById("fNewPass").value;
  const confPass   = document.getElementById("fConfPass").value;

  document.getElementById("msgErrorPass").classList.remove("visible");
  document.getElementById("msgOkPass").classList.remove("visible");

  if (!passActual) {
    setErrorPass("Ingresa tu contraseña actual."); return;
  }
  if (newPass.length < 6) {
    setErrorPass("La nueva contraseña debe tener al menos 6 caracteres."); return;
  }
  if (newPass !== confPass) {
    setErrorPass("Las contraseñas nuevas no coinciden."); return;
  }
  if (passActual === newPass) {
    setErrorPass("La nueva contraseña debe ser diferente a la actual."); return;
  }

  const btn = document.getElementById("btnCambiarPass");
  btnCargando(btn, true);

  try {
    // Re-autenticar primero con la contraseña actual
    const user       = auth.currentUser;
    const credential = EmailAuthProvider.credential(user.email, passActual);
    await reauthenticateWithCredential(user, credential);

    // Ahora cambiar la contraseña
    await updatePassword(user, newPass);

    document.getElementById("textoOkPass").textContent = "✓ Contraseña actualizada correctamente.";
    document.getElementById("msgOkPass").classList.add("visible");

    // Limpiar campos y resetear botones ojo
    ["fPassActual","fNewPass","fConfPass"].forEach(id => {
      document.getElementById(id).value = "";
      document.getElementById(id).type  = "password";
    });
    ["btnVerPassActual","btnVerPassNueva","btnVerPassConf"].forEach(id => {
      document.getElementById(id).textContent = "👁";
    });

  } catch (e) {
    const errores = {
      "auth/wrong-password":        "Contraseña actual incorrecta.",
      "auth/invalid-credential":    "Contraseña actual incorrecta.",
      "auth/weak-password":         "La nueva contraseña es muy débil.",
      "auth/requires-recent-login": "Sesión expirada. Cierra sesión y vuelve a ingresar.",
    };
    setErrorPass(errores[e.code] || "Error: " + e.message);
    console.error(e);
  } finally {
    btnCargando(btn, false);
  }
});

// ── Helpers ───────────────────────────────────────────────
function setErrorPass(msg) {
  document.getElementById("textoErrorPass").textContent = msg;
  document.getElementById("msgErrorPass").classList.add("visible");
}
function ocultarMensajes() {
  document.getElementById("msgError").classList.remove("visible");
  document.getElementById("msgOk").classList.remove("visible");
}
function mostrarError(msg) {
  document.getElementById("textoError").textContent = msg;
  document.getElementById("msgError").classList.add("visible");
  document.getElementById("msgOk").classList.remove("visible");
}
function mostrarOk(msg) {
  document.getElementById("textoOk").textContent = msg;
  document.getElementById("msgOk").classList.add("visible");
  document.getElementById("msgError").classList.remove("visible");
}
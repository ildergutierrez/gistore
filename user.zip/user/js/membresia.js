// ============================================================
//  membresia.js — Portal Vendedor GI Store
//  Muestra estado membresía + inyecta botón Wompi
// ============================================================
import { db, auth } from "./firebase.js";
import {
  doc, getDoc, collection, query,
  where, orderBy, limit, getDocs
} from "https://www.gstatic.com/firebasejs/12.10.0/firebase-firestore.js";
import { onAuthStateChanged, signOut }
  from "https://www.gstatic.com/firebasejs/12.10.0/firebase-auth.js";

// ── Llave pública Wompi (sandbox) ──────────────────────────
const WOMPI_LLAVE_PUBLICA = "pub_test_TtJTkVzWXZARy6JSxSkd7JiOvzEvkDPG";

// ── Utilidades de fecha ─────────────────────────────────────
function formatFecha(ts) {
  if (!ts) return "—";
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleDateString("es-CO", { year: "numeric", month: "long", day: "numeric" });
}

function diasRestantes(ts) {
  if (!ts) return -1;
  const fin = ts.toDate ? ts.toDate() : new Date(ts);
  const hoy = new Date();
  return Math.ceil((fin - hoy) / (1000 * 60 * 60 * 24));
}

function formatMoneda(n) {
  return "$" + Number(n).toLocaleString("es-CO");
}

// ── Badge días restantes ────────────────────────────────────
function badgeDias(dias) {
  if (dias < 0)  return `<span class="dias-restantes venc">❌ Vencida</span>`;
  if (dias <= 7) return `<span class="dias-restantes warn">⚠️ ${dias} días restantes</span>`;
  return `<span class="dias-restantes ok">✅ ${dias} días restantes</span>`;
}

// ── Alerta superior ─────────────────────────────────────────
function mostrarAlerta(tipo, mensaje) {
  const el = document.getElementById("alertaMembresia");
  if (!el) return;
  el.style.display = "flex";
  el.innerHTML = `<div class="alerta-membresia ${tipo}"><span>${tipo === "error" ? "❌" : tipo === "warn" ? "⚠️" : "✅"}</span><span>${mensaje}</span></div>`;
}

// ── Renderizar estado membresía ─────────────────────────────
function renderEstado(membresia) {
  const el = document.getElementById("estadoContenido");
  if (!el) return;

  if (!membresia) {
    el.innerHTML = `
      <div class="estado-fila">
        <span class="estado-fila-label">Estado</span>
        <span class="badge badge-inactivo">Sin membresía</span>
      </div>
      <p style="font-size:.83rem;color:var(--texto-suave);margin-top:.75rem">
        Aún no tienes una membresía activa. Elige un plan y realiza tu pago para activar tu acceso.
      </p>`;
    mostrarAlerta("error", "No tienes membresía activa. Realiza tu pago para acceder a todas las funciones.");
    return;
  }

  const dias = diasRestantes(membresia.fecha_fin);
  const pct  = Math.max(0, Math.min(100, Math.round((dias / 30) * 100)));

  el.innerHTML = `
    <div class="estado-fila">
      <span class="estado-fila-label">Estado</span>
      ${badgeDias(dias)}
    </div>
    <div class="estado-fila">
      <span class="estado-fila-label">Plan activo</span>
      <span class="estado-fila-valor">${membresia.plan || "Estándar"}</span>
    </div>
    <div class="estado-fila">
      <span class="estado-fila-label">Inicio</span>
      <span class="estado-fila-valor">${formatFecha(membresia.fecha_inicio)}</span>
    </div>
    <div class="estado-fila">
      <span class="estado-fila-label">Vence</span>
      <span class="estado-fila-valor">${formatFecha(membresia.fecha_fin)}</span>
    </div>
    <div class="progreso-wrap">
      <div class="progreso-label">
        <span>Tiempo restante</span>
        <span>${Math.max(0, dias)} / 30 días</span>
      </div>
      <div class="progreso-barra">
        <div class="progreso-fill" style="width:${pct}%"></div>
      </div>
    </div>`;

  if (dias < 0)  mostrarAlerta("error", "Tu membresía ha vencido. Renueva ahora para recuperar el acceso.");
  else if (dias <= 7) mostrarAlerta("warn", `Tu membresía vence en ${dias} día${dias !== 1 ? "s" : ""}. Renueva para no perder el acceso.`);
  else mostrarAlerta("ok", `¡Tu membresía está activa! Tienes ${dias} días disponibles.`);
}

// ── Renderizar historial de pagos ───────────────────────────
function renderHistorial(pagos) {
  const el = document.getElementById("historialContenido");
  if (!el) return;

  if (!pagos || pagos.length === 0) {
    el.innerHTML = `<p style="font-size:.83rem;color:var(--texto-suave);text-align:center;padding:1rem 0">Sin pagos registrados aún.</p>`;
    return;
  }

  el.innerHTML = pagos.map(p => `
    <div class="historial-item">
      <div>
        <div style="font-size:.85rem;font-weight:600">${p.plan || "Membresía"}</div>
        <div class="historial-fecha">${formatFecha(p.fecha_pago || p.creado_en)}</div>
      </div>
      <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;justify-content:flex-end">
        <span class="historial-monto">${formatMoneda(p.monto || 0)}</span>
        <span class="badge ${p.estado === "aprobado" ? "badge-activo" : "badge-inactivo"}" style="font-size:.75rem">
          ${p.estado === "aprobado" ? "✓ Aprobado" : p.estado || "Pendiente"}
        </span>
      </div>
    </div>`).join("");
}

// ── Inyectar botón Wompi ────────────────────────────────────
function inyectarBotonWompi(vendedorId, monto, referencia, label) {
  const wrap = document.getElementById("wompi-btn-wrap");
  if (!wrap) return;

  // Limpiar botón anterior
  wrap.innerHTML = "";

  const script = document.createElement("script");
  script.src   = "https://checkout.wompi.co/widget.js";
  script.setAttribute("data-render",      "button");
  script.setAttribute("data-public-key",  WOMPI_LLAVE_PUBLICA);
  script.setAttribute("data-currency",    "COP");
  script.setAttribute("data-amount-in-cents", String(monto * 100));
  script.setAttribute("data-reference",   referencia);
  script.setAttribute("data-signature:integrity", ""); // Se calcula en backend para producción
  script.setAttribute("data-redirect-url",
    `${location.origin}/user/pages/pago-resultado.html?ref=${referencia}`);

  // Metadatos del vendedor para el webhook
  script.setAttribute("data-customer-data:email",      auth.currentUser?.email || "");
  script.setAttribute("data-customer-data:full-name",  auth.currentUser?.displayName || "");

  wrap.appendChild(script);
}

// ── Generar referencia única ────────────────────────────────
function generarReferencia(vendedorId, monto) {
  const ts = Date.now();
  return `GIS-${vendedorId.slice(0, 8)}-${monto}-${ts}`;
}

// ── Selección de plan ───────────────────────────────────────
function initSeleccionPlan(vendedorId) {
  const planes = document.querySelectorAll(".plan-card");
  const resumenLabel = document.getElementById("resumenLabel");
  const resumenMonto = document.getElementById("resumenMonto");

  let planActual = document.getElementById("planEstandar");

  function seleccionar(card) {
    planes.forEach(p => p.classList.remove("seleccionado"));
    card.classList.add("seleccionado");
    planActual = card;

    const monto = parseInt(card.dataset.monto);
    const label = card.dataset.label;
    const ref   = generarReferencia(vendedorId, monto);

    if (resumenLabel) resumenLabel.textContent = label;
    if (resumenMonto) resumenMonto.textContent = formatMoneda(monto);

    inyectarBotonWompi(vendedorId, monto, ref, label);
  }

  planes.forEach(card => {
    card.addEventListener("click", () => seleccionar(card));
  });

  // Inicializar con plan seleccionado por defecto
  const def = document.querySelector(".plan-card.seleccionado") || planes[0];
  if (def) seleccionar(def);
}

// ── Fecha de hoy ────────────────────────────────────────────
function setFechaHoy() {
  const el = document.getElementById("fechaHoy");
  if (el) el.textContent = new Date().toLocaleDateString("es-CO",
    { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}

// ── Main ─────────────────────────────────────────────────────
onAuthStateChanged(auth, async (user) => {
  if (!user) { location.href = "../../index.html"; return; }

  setFechaHoy();

  // Cerrar sesión
  const btnSalir = document.getElementById("btnSalir");
  if (btnSalir) btnSalir.addEventListener("click", () => signOut(auth).then(() => location.href = "../../index.html"));

  try {
    // Cargar datos del vendedor
    const vendSnap = await getDoc(doc(db, "vendedores", user.uid));
    if (!vendSnap.exists()) { location.href = "../../index.html"; return; }
    const vendedor = vendSnap.data();

    const nomEl = document.getElementById("vendedorNombre");
    if (nomEl) nomEl.textContent = vendedor.nombre || "Vendedor";

    // Cargar membresía activa
    const memRef  = collection(db, "membresias");
    const memQ    = query(memRef,
      where("vendedor_id", "==", user.uid),
      where("estado", "==", "activa"),
      orderBy("fecha_fin", "desc"),
      limit(1));
    const memSnap = await getDocs(memQ);
    const membresia = memSnap.empty ? null : memSnap.docs[0].data();

    renderEstado(membresia);

    // Cargar historial de pagos
    const pagosQ    = query(collection(db, "pagos"),
      where("vendedor_id", "==", user.uid),
      orderBy("creado_en", "desc"),
      limit(10));
    const pagosSnap = await getDocs(pagosQ);
    const pagos     = pagosSnap.docs.map(d => d.data());
    renderHistorial(pagos);

    // Inicializar selección de plan + botón Wompi
    initSeleccionPlan(user.uid);

  } catch (err) {
    console.error("Error cargando membresía:", err);
    document.getElementById("estadoContenido").innerHTML =
      `<p style="color:var(--error);font-size:.85rem">Error al cargar la membresía. Recarga la página.</p>`;
  }
});
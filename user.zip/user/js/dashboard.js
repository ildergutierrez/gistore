// ============================================================
//  dashboard.js — Portal vendedor
// ============================================================
import { cerrarSesion, protegerPagina } from "../js/auth.js";
import { obtenerVendedorPorUid, obtenerMembresiaVendedor,
         obtenerMisProductos, membresiaVigente } from "../js/db.js";
import { fechaHoy, formatoPrecio } from "../js/ui.js";
import { auth } from "../js/firebase.js";
import { onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/12.10.0/firebase-auth.js";

protegerPagina("../index.html");

document.getElementById("fechaHoy").textContent = fechaHoy();
document.getElementById("btnSalir").addEventListener("click", async () => {
  await cerrarSesion();
  window.location.href = "../index.html";
});

const WHATSAPP_ADMIN = "573145891108";

// Esperar a que Auth esté listo antes de cargar datos
onAuthStateChanged(auth, async (user) => {
  if (!user) return;

  try {
    const vendedor = await obtenerVendedorPorUid(user.uid);

    if (!vendedor) {
      document.getElementById("bienvenida").textContent = "⚠ Perfil no encontrado.";
      document.getElementById("panelMembresia").innerHTML =
        `<p style="color:var(--texto-medio);font-size:.87rem">
          No se encontró un perfil asociado a esta cuenta.<br/>
          Contacta al administrador.
        </p>`;
      document.getElementById("statProductos").textContent = "—";
      document.getElementById("statActivos").textContent   = "—";
      document.getElementById("statInactivos").textContent = "—";
      return;
    }

    // Guardar en sessionStorage para otras páginas
    sessionStorage.setItem("vendedor_id",     vendedor.id);
    sessionStorage.setItem("vendedor_nombre", vendedor.nombre);
    sessionStorage.setItem("vendedor_color",  vendedor.color || "#1a6b3c");

    document.getElementById("bienvenida").textContent     = "Hola, " + vendedor.nombre + " 👋";
    document.getElementById("vendedorNombre").textContent = vendedor.nombre;

    // Membresía
    const mem = await obtenerMembresiaVendedor(vendedor.id);
    renderMembresia(mem, vendedor);

    // Productos
    const productos = await obtenerMisProductos(vendedor.id);
    const activos   = productos.filter(p => p.activo).length;
    document.getElementById("statProductos").textContent = productos.length || "0";
    document.getElementById("statActivos").textContent   = activos || "0";
    document.getElementById("statInactivos").textContent = (productos.length - activos) || "0";

  } catch (e) {
    console.error(e);
    document.getElementById("bienvenida").textContent = "Error al cargar datos.";
  }
});

function renderMembresia(mem, vendedor) {
  const el      = document.getElementById("panelMembresia");
  const hoy     = new Date().toISOString().split("T")[0];
  const vigente = membresiaVigente(mem);

  if (!mem) {
    el.innerHTML = membresiaHTML("inactivo", "Sin membresía",
      "No tienes membresía activa. Contacta al administrador.", vendedor);
    return;
  }

  const dias = Math.ceil((new Date(mem.fecha_fin) - new Date(hoy)) / (1000*60*60*24));

  if (!vigente) {
    el.innerHTML = membresiaHTML("vencida", "Membresía vencida",
      "Tu membresía venció el " + mem.fecha_fin + ". Renuévala para seguir activo.", vendedor);
    return;
  }

  let alerta = "";
  if (dias <= 7) {
    alerta = `<div class="msg-error visible" style="margin-bottom:1rem">
      <span>⚠&nbsp;</span><span>Tu membresía vence en ${dias} día${dias!==1?'s':''}. ¡Renuévala pronto!</span>
    </div>`;
  } else if (dias <= 30) {
    alerta = `<div style="background:var(--adv-bg);border:1.5px solid var(--adv-borde);border-radius:8px;padding:.6rem .9rem;font-size:.83rem;color:var(--advertencia);margin-bottom:1rem">
      ⏰ Tu membresía vence en ${dias} días (${mem.fecha_fin})
    </div>`;
  }

  el.innerHTML = `
    ${alerta}
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem">
      <div>
        <p style="font-size:.78rem;color:var(--texto-suave);text-transform:uppercase;letter-spacing:.05em;font-weight:600;margin-bottom:.3rem">Estado de membresía</p>
        <span class="badge badge-activo" style="font-size:.85rem;padding:.3rem .9rem">✓ Activa</span>
        <p style="font-size:.83rem;color:var(--texto-medio);margin-top:.5rem">Válida hasta: <strong>${mem.fecha_fin}</strong> · ${dias} días restantes</p>
      </div>
      <a href="https://wa.me/${WHATSAPP_ADMIN}?text=${encodeURIComponent('Hola, soy ' + vendedor.nombre + ' (ID: ' + vendedor.id + '), quiero renovar mi membresía de GI Store.')}"
         target="_blank" class="btn btn-secundario">
        💬 Renovar membresía
      </a>
    </div>`;
}

function membresiaHTML(estado, titulo, msg, vendedor) {
  return `
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem">
      <div>
        <p style="font-size:.78rem;color:var(--texto-suave);text-transform:uppercase;letter-spacing:.05em;font-weight:600;margin-bottom:.3rem">Estado de membresía</p>
        <span class="badge badge-${estado}" style="font-size:.85rem;padding:.3rem .9rem">${titulo}</span>
        <p style="font-size:.83rem;color:var(--texto-medio);margin-top:.5rem">${msg}</p>
      </div>
      <a href="https://wa.me/${WHATSAPP_ADMIN}?text=${encodeURIComponent('Hola, soy ' + vendedor.nombre + ' (ID: ' + vendedor.id + '), quiero activar mi membresía de GI Store.')}"
         target="_blank" class="btn btn-primary">
        💬 Contactar administrador
      </a>
    </div>`;
}